export function Config() {
  return {
    github: {
      user: 'angular',
      repository: 'angular.js'
    }
  }
}
